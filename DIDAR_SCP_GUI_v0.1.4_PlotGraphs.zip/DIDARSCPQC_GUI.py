from datetime import datetime
import os.path

import numpy as np
import threading
import tkinter as tk
import traceback
from functools import partial
from tkinter import ttk
from tkinter.filedialog import askdirectory, askopenfilename

from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

import logic


def parse_diagnostic_output_file(diagnostic_file):
    data_list = []
    with open(diagnostic_file, 'r') as c:
        for line in c.read().split('\n'):
            if line.strip() and ":" in line:
                key, value = line.split(':')
                data_list.append((key, float(value)))
    return data_list


class Window(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        self.title("D.I.D.A.R.S.C.P.G.U.I.")
        self.geometry("720x350")

        self.init_UI()

        self.inputs = {}

    def init_UI(self):
        # Create a frame for the buttons
        frame = ttk.Frame(self)
        frame.pack(side="top", fill="both", expand=True)

        # create a label - select folder
        label_1 = ttk.Label(frame, text="Select a folder containing files to process:")
        label_1.grid(row=0, column=0, sticky="w", padx=10)

        # create a button - select folder
        button = ttk.Button(frame, text="Select Folder", command=partial(self.select_folder, "folder_containing_files"))
        button.grid(row=0, column=1, sticky="w")

        # --------------------------------------
        # create a label - enter mass tolerance
        label_2 = ttk.Label(frame, text="Enter mass tolerance in Da - recommended 0.002 for FT / 0.005 for TOF:")
        label_2.grid(row=1, column=0, sticky="w", padx=10)

        # create a entry - enter mass tolerance
        self.entry_1 = ttk.Entry(frame)
        self.entry_1.grid(row=1, column=1, sticky="w")

        # --------------------------------------
        # create label - Enter minimum number of diagnostic ions
        label_3 = ttk.Label(frame, text="Enter minimum number of diagnostic or reporter ions:")
        label_3.grid(row=2, column=0, sticky="w", padx=10)

        # create an entry - Enter minimum number of diagnostic ions
        self.entry_2 = ttk.Entry(frame)
        self.entry_2.grid(row=2, column=1, sticky="w")

        # --------------------------------------
        # create a label - Select reporter file
        label_4 = ttk.Label(frame, text="Select reporter file:")
        label_4.grid(row=3, column=0, sticky="w", padx=10)

        # create a button - select reporter file
        button_2 = ttk.Button(frame, text="Select File", command=partial(self.select_file, "reporter_file"))
        button_2.grid(row=3, column=1, sticky="w")

        # --------------------------------------
        # create a label - Select Glyco file
        label_5 = ttk.Label(frame, text="Select Glyco file:")
        label_5.grid(row=4, column=0, sticky="w", padx=10)

        # create a button - select Glyco file
        button_3 = ttk.Button(frame, text="Select File", command=partial(self.select_file, "glyco_file"))
        button_3.grid(row=4, column=1, sticky="w")

        # --------------------------------------
        # submit button
        button_4 = ttk.Button(frame, text="QC your SCP files!", command=self.submit)
        button_4.grid(row=5, column=1, sticky="w", pady=10)

        # --------------------------------------
        # create a label - output
        self.label_output = ttk.Label(frame, text="Output:")
        self.label_output.grid(row=6, column=0, sticky="ews", padx=10, columnspan=2)

        # configure the column and row grid
        for i in range(2):
            frame.columnconfigure(i, weight=1)
        for i in range(6):
            frame.rowconfigure(i, weight=1)

    def select_folder(self, key: str):
        folder = askdirectory()
        if folder:
            self.inputs[key] = folder
            print(self.inputs)

    def select_file(self, key: str):
        file = askopenfilename()
        if file:
            self.inputs[key] = file
            print(self.inputs)

    def submit(self):
        try:
            working_directory = self.inputs["folder_containing_files"]
        except KeyError:
            self.show_output("Please select a folder containing files to process.")
            return
        try:
            mass_tolerance = float(self.entry_1.get())
        except ValueError:
            self.show_output("Please enter a valid mass tolerance")
            return
        try:
            min_num_diag_ions = int(self.entry_2.get())
        except ValueError:
            self.show_output("Please enter a valid number for the minimum number of diagnostic ions")
            return

        try:
            reporter_file = self.inputs["reporter_file"]
        except KeyError:
            self.show_output("Please select a reporter file")
            return
        try:
            glyco_file = self.inputs["glyco_file"]
        except KeyError:
            self.show_output("Please select a glyco file")
            return

        if not all((working_directory, mass_tolerance, reporter_file, glyco_file)):
            self.show_output("Please fill all fields before submitting")
            return

        # use threadpool executor to show output after processing is done
        threading.Thread(target=self.execute, args=(working_directory, reporter_file, glyco_file, mass_tolerance,
                                                    min_num_diag_ions)).start()

    @staticmethod
    def show_message(message: str):
        tk.messagebox.showinfo("Message", message)

    def show_output(self, output: str):
        self.label_output.configure(text=output)

    def execute(self, *args):
        try:
            output, output_filtered_file_list, output_diagnostic_file_list = logic.run(*args)
            self.show_output(output)
            for file in output_diagnostic_file_list:
                self.show_graph(file)
                break  # only show the first file (Diagnostic file generated from the algorithm)
            # self.show_graph("work_dir/Diagnostic_Diagnostic_Small_test_file.mgf")  # todo: remove this (used for testing on predefined file)
        except Exception as e:
            self.show_output(traceback.format_exc())

    def show_graph(self, diagnostic_filename):
        self.graph_window = tk.Toplevel()
        self.graph_window.title("Diagnostic ions")
        self.graph_window.geometry("720x350")
        self.graph_window.protocol("WM_DELETE_WINDOW", self.graph_window.destroy)
        self.graph_window.focus_force()
        self.graph_window.grab_set()

        fig = Figure(figsize=(5, 4), dpi=100)
        ax = fig.add_subplot(111)
        ax.set_title(os.path.basename(diagnostic_filename))
        data_list = parse_diagnostic_output_file(diagnostic_filename)
        if not data_list:
            self.show_output("No data found in file")
            # close the window
            self.graph_window.destroy()
            return
        x_list = [x[0] for x in data_list]
        y_list = [x[1] for x in data_list]
        y_max = round(max(y_list) / 10) * 10  # round to nearest 10
        ax.bar(x_list, y_list)

        ax2 = ax.twinx()
        y_list_percent = [f"{x}%" for x in range(0, 101, 10)]
        ax2.bar(x_list, y_list)
        ax2.set_yticks(np.linspace(0, y_max, 11))
        ax2.set_yticklabels(y_list_percent)

        canvas = FigureCanvasTkAgg(fig, self.graph_window)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # image file name
        time_stamp = int(datetime.now().replace(microsecond=0).timestamp())
        image_file_name = os.path.splitext(diagnostic_filename)[0] + f"_{time_stamp}" + ".png"
        # save image
        fig.savefig(image_file_name)
        print(f"Saved image to {image_file_name}")


if __name__ == '__main__':
    w = Window()
    w.mainloop()
